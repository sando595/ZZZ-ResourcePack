ZZZ CUSTOM ITEMS - Minecraft 1.21.11

Instalacja:
1. Rozpakuj ZIP. Folder ZZZ_Custom_Items zawiera pack.mcmeta i assets.
2. Skopiuj folder albo ZIP do .minecraft/resourcepacks (klientów) lub hostuj ZIP i ustaw link w server.properties jako resource-pack.
3. Włącz paczkę w Opcje -> Pakiety zasobów.

Komendy testowe (OP):
/give @p minecraft:feather[minecraft:custom_model_data={floats:[1.0]}]
/give @p minecraft:diamond_sword[minecraft:custom_model_data={floats:[2.0]}]
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[3.0]}]
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[4.0]}]
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[5.0]}]
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[6.0]}]
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[7.0]}]
/give @p minecraft:diamond_pickaxe[minecraft:custom_model_data={floats:[8.0]}]

UWAGI:
- Zwykle przedmioty bez Custom Model Data zachowują wygląd vanilla.
- PNG zostały podpięte jako płaskie itemy 2D (minecraft:item/generated).
- Pliki 3-7 to pięć ręcznie wybieranych wariantów kuszy. Ten pakiet sam nie przełącza ich automatycznie podczas naciągania.
- ZIP zawiera PNG, proste modele JSON i definicje itemów. Nie zawiera modeli 3D.
